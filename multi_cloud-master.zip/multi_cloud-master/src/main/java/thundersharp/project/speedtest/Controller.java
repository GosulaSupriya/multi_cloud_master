package thundersharp.project.speedtest;

public class Controller {
}
