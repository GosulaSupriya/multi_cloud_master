package thundersharp.project.speedtest;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface PrimaryRepository extends MongoRepository<DataEntity, String> {

}
