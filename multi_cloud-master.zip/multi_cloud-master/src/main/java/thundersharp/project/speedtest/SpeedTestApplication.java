package thundersharp.project.speedtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpeedTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpeedTestApplication.class, args);
    }

}
