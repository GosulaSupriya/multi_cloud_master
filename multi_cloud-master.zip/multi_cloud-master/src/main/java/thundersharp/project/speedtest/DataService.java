package thundersharp.project.speedtest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DataService {

    private final PrimaryRepository primaryRepository;

    private final SecondaryRepository secondaryRepository;

    @Autowired
    public DataService(PrimaryRepository primaryRepository, SecondaryRepository secondaryRepository) {
        this.primaryRepository = primaryRepository;
        this.secondaryRepository = secondaryRepository;
    }

    public long uploadToSingleDatabase(String data) {
        long startTime = System.currentTimeMillis();
        DataEntity entity = new DataEntity();
        entity.setContent(data);
        primaryRepository.save(entity);
        return System.currentTimeMillis() - startTime;
    }

    public long uploadToTwoDatabases(String data) {
        long startTime = System.currentTimeMillis();
        int mid = data.length() / 2;

        DataEntity firstHalf = new DataEntity();
        firstHalf.setContent(data.substring(0, mid));
        primaryRepository.save(firstHalf);

        DataEntity secondHalf = new DataEntity();
        secondHalf.setContent(data.substring(mid));
        secondaryRepository.save(secondHalf);

        return System.currentTimeMillis() - startTime;
    }
}