package thundersharp.project.speedtest;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface SecondaryRepository extends MongoRepository<DataEntity, String> {

}