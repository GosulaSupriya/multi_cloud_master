package thundersharp.project.speedtest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://127.0.0.1:5500")
@RequestMapping("/data")
public class DataController {

    @Autowired
    private MongoTemplate mongoTemplate1;

    @Autowired
    private MongoTemplate mongoTemplate2;
    @Autowired
    private DataService dataService;

    @PostMapping("/upload")
    public ResponseEntity<Map<String, Object>> uploadData(@RequestBody Map<String, Object> requestData) {
        String data = (String) requestData.get("data");
        Boolean divide = (Boolean) requestData.get("divide");

        long time = 0;

        if (divide != null && divide) {
            time = dataService.uploadToTwoDatabases(data);
        } else {
            // Upload the entire data to a single database
            time = dataService.uploadToSingleDatabase(data);
        }

        // Prepare response
        Map<String, Object> response = new HashMap<>();
        response.put("timeTaken", time);
        return ResponseEntity.ok(response);
    }
}