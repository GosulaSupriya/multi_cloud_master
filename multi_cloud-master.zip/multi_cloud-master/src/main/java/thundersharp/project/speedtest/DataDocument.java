package thundersharp.project.speedtest;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "data")
public class DataDocument {
    private String id;
    private String content;

    public DataDocument(String content) {
        this.content = content;
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}